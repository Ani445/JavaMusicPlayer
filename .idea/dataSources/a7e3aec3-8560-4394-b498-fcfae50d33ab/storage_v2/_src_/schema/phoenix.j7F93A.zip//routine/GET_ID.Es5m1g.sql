create
    definer = root@localhost function GET_ID(TABLE_NAME varchar(10)) returns varchar(5) deterministic
BEGIN
    DECLARE
        LI VARCHAR(5);
    SELECT LAST_ID FROM LAST_IDS
        WHERE LAST_IDS.TABLE_NAME = TABLE_NAME
        INTO LI;
    RETURN LI;
END;

