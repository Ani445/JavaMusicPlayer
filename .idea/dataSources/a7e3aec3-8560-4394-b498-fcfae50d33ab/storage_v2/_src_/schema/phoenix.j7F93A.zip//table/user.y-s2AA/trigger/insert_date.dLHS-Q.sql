create definer = root@localhost trigger INSERT_DATE
    before insert
    on user
    for each row
BEGIN
    SET NEW.JOIN_DATE = SYSDATE();
END;

