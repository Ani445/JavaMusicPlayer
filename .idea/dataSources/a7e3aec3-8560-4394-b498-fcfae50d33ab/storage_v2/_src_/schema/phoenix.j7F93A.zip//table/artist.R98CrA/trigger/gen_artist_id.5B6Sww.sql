create definer = root@localhost trigger GEN_ARTIST_ID
    before insert
    on artist
    for each row
BEGIN
    DECLARE
        ID INT;
    SELECT GET_ID('ARTIST') FROM DUAL INTO ID;
    SET ID = ID + 1;
    SET NEW.ARTIST_ID = CAST(ID AS CHAR);
    UPDATE LAST_IDS SET LAST_IDS.LAST_ID = ID WHERE LAST_IDS.TABLE_NAME = 'ARTIST';
END;

