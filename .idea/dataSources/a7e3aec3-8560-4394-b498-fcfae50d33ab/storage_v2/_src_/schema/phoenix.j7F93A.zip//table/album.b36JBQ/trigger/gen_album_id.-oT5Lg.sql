create definer = root@localhost trigger GEN_ALBUM_ID
    before insert
    on album
    for each row
BEGIN
    DECLARE
        ID INT;
    SELECT GET_ID('ALBUM') FROM DUAL INTO ID;
    SET ID = ID + 1;
    SET NEW.ALBUM_ID = CAST(ID AS CHAR);
    UPDATE LAST_IDS SET LAST_IDS.LAST_ID = ID WHERE LAST_IDS.TABLE_NAME = 'ALBUM';
END;

