create definer = root@localhost trigger GEN_SONG_ID
    before insert
    on song
    for each row
BEGIN
    DECLARE
        ID INT;
    SELECT GET_ID('SONG') FROM DUAL INTO ID;
    SET ID = ID + 1;
    SET NEW.SONG_ID = CAST(ID AS CHAR);
    UPDATE LAST_IDS SET LAST_IDS.LAST_ID = ID WHERE LAST_IDS.TABLE_NAME = 'SONG';
END;

