create definer = root@localhost trigger GEN_PLAYLIST_ID
    before insert
    on playlist
    for each row
BEGIN
    DECLARE
        ID INT;
    SELECT GET_ID('PLAYLIST') FROM DUAL INTO ID;
    SET ID = ID + 1;
    SET NEW.PLAYLIST_ID = CAST(ID AS CHAR);
    UPDATE LAST_IDS SET LAST_IDS.LAST_ID = ID WHERE LAST_IDS.TABLE_NAME = 'PLAYLIST';
END;

